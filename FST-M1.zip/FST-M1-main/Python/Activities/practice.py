name = input("Enter the name")
age = int(input("Enter the age"))

year = str( ( 2022 - age ) + 100 )
print( name + " will be 100 years old in the year " + year )
