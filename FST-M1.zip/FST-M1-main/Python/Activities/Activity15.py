
try:
    print(name)
except NameError:
    print("name hasn't been defined yet.")
