package examples;

public class AnnotationExamples {


}
