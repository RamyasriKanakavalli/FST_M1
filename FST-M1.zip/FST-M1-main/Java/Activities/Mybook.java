package Activities;

public class Mybook extends Book{
    @Override
    void setTitle(String s) {
        title = s;
    }
}
