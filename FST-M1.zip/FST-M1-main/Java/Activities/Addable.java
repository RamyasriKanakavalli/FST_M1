package Activities;

public interface Addable {

    int add(int a, int b);
}
